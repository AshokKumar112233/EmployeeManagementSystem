package com.example.Controller;


import com.example.Model.Employee;
import com.example.Service.EmployeeService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;



@RestController
@RequestMapping("/api/employees")
public class EmployeeController {
	
	private final EmployeeService employeeService;

    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @GetMapping
    public ResponseEntity<List<Employee>> getAllEmployees() {
        return ResponseEntity.ok(employeeService.getAllEmployees());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Employee> getEmployeeById(@PathVariable String id) {
        return ResponseEntity.ok(employeeService.getEmployeeById(id));
    }

    @PostMapping("/{id}/work")
    public ResponseEntity<Void> updateWorkDays(@PathVariable String id, @RequestParam int daysWorked) {
        employeeService.updateWorkDays(id, daysWorked);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/{id}/vacation")
    public ResponseEntity<Void> takeVacation(@PathVariable String id, @RequestParam float vacationDays) {
        employeeService.updateVacation(id, vacationDays);
        return ResponseEntity.ok().build();
    }
	
}
