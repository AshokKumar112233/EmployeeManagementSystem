package com.example.Model;

public abstract class Employee {
    private final String id;
    private final String name;
    private float vacationDaysAccumulated;
    private final float maxVacationDays;
    private final int maxWorkDays = 260;

    public Employee(String id, String name, float maxVacationDays) {
        this.id = id;
        this.name = name;
        this.vacationDaysAccumulated = 0;
        this.maxVacationDays = maxVacationDays;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public float getVacationDaysAccumulated() {
        return vacationDaysAccumulated;
    }

    public void work(int daysWorked) {
        if (daysWorked < 0 || daysWorked > maxWorkDays) {
            throw new IllegalArgumentException("Days worked must be between 0 and " + maxWorkDays);
        }
        vacationDaysAccumulated += (daysWorked / (float) maxWorkDays) * maxVacationDays;
    }

    public void takeVacation(float days) {
        if (days < 0 || days > vacationDaysAccumulated) {
            throw new IllegalArgumentException("Cannot take more vacation than available.");
        }
        vacationDaysAccumulated -= days;
    }
}

