package com.example.Model;

public class HourlyEmployee extends Employee {
    private static final float HOURLY_MAX_VACATION_DAYS = 10;

    public HourlyEmployee(String id, String name) {
        super(id, name, HOURLY_MAX_VACATION_DAYS);
    }
}
