package com.example.Model;


public class Manager extends Employee {
    private static final float MANAGER_MAX_VACATION_DAYS = 30;

    public Manager(String id, String name) {
        super(id, name, MANAGER_MAX_VACATION_DAYS);
    }
}

