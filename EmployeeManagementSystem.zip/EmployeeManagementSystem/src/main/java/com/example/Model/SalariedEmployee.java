package com.example.Model;

public class SalariedEmployee extends Employee {
    private static final float SALARIED_MAX_VACATION_DAYS = 15;

    public SalariedEmployee(String id, String name) {
        super(id, name, SALARIED_MAX_VACATION_DAYS);
    }
}

