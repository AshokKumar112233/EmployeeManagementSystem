package com.example.Service;

import com.example.Model.*;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class EmployeeService {
    private final List<Employee> employees;

    public EmployeeService() {
        this.employees = new ArrayList<>();
        initializeEmployees();
    }

    private void initializeEmployees() {
        for (int i = 0; i < 10; i++) {
            employees.add(new HourlyEmployee(UUID.randomUUID().toString(), "Hourly Employee " + (i + 1)));
            employees.add(new SalariedEmployee(UUID.randomUUID().toString(), "Salaried Employee " + (i + 1)));
            employees.add(new Manager(UUID.randomUUID().toString(), "Manager " + (i + 1)));
        }
    }

    public List<Employee> getAllEmployees() {
        return employees;
    }

    public Employee getEmployeeById(String id) {
        return employees.stream()
                .filter(employee -> employee.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Employee not found"));
    }

    public void updateWorkDays(String id, int daysWorked) {
        Employee employee = getEmployeeById(id);
        employee.work(daysWorked);
    }

    public void updateVacation(String id, float vacationDays) {
        Employee employee = getEmployeeById(id);
        employee.takeVacation(vacationDays);
    }
}

